# assignment4

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

![image](https://github.com/Tueny/mobile-assignment4/assets/158063417/689ef2b6-55f5-49ad-a11a-353c3c23e5b8)
![image](https://github.com/Tueny/mobile-assignment4/assets/158063417/57c41c2b-3957-411d-903f-e54b9c7272d9)
![image](https://github.com/Tueny/mobile-assignment4/assets/158063417/67f5c106-1500-4811-bcd5-5bf142a0211e)
