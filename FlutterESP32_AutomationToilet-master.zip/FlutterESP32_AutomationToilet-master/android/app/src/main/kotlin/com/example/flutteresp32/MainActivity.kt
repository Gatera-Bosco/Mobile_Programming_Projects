package com.example.flutteresp32

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
