package com.example.mobile_assignemt2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
