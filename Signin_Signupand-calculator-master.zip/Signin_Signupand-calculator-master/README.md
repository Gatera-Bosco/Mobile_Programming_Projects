Sign in SIgn up and Calculator working

# mobile_assignemt2

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
![Screenshot_20240625-131724](https://github.com/Tueny/Signin_Signupand-calculator/assets/158063417/e64b0888-0823-4749-b2aa-c452764f76ac)
![Screenshot_20240625-131728](https://github.com/Tueny/Signin_Signupand-calculator/assets/158063417/6bc7d3cb-579e-4c6d-974c-fbc9e88c05fc)
![Screenshot_20240625-131732](https://github.com/Tueny/Signin_Signupand-calculator/assets/158063417/c930fc78-3ea4-4fe5-ac2c-9beaa7f650f1)


