import 'package:flutter/material.dart';

class DarkColors {
  static const scaffoldBgColor = Color(0xFF1E1E1E);
  static const sheetBgColor = Color(0xFF2E2E2E);
  static const btnBgColor = Color(0xFF3E3E3E);
  static const operatorColor = Color(0xFFFFA500);
}
